﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Roll_Dice : MonoBehaviour {

    public Text Dice;

    int roll;

    public void RollDice() {
        roll = Random.Range(1, 6);
        roll += Random.Range(1, 6);
        Dice.text = "Dice Roll: " + roll;    
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
