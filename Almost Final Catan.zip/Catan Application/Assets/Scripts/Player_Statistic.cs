﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player_Statistic : MonoBehaviour {
    public Scene victory;
    //Player Resource Values
    public int lumber;
    public int ore;
    public int wool;
    public int grain;
    public int brick;
    public int vp;
    public int rCards;
    public Text lumberText;
    public Text oreText;
    public Text woolText;
    public Text brickText;
    public Text grainText;
    public Text vpText;
    public Text rCardsText;
    public bool buildSettlement = false;
    public bool buildRoad = false;
    public bool buildDevelopment = false;
    public Game_Mechanics gameBoard;
    private int firstRoads = 0;
    private int firstSettlements = 0;
    //List element for storing which settlements the player owns
    public List<int> settlements = new List<int>();

    //adds tiles adjacent to the placed settlements to the players list for receiving resources
    public void addTiles (int[] hexes) {
        
        for (int i = 0; i < hexes.Length; i++)
        {
            settlements.Add(hexes[i]);          
        }

        Debug.Log("Settlements added to player");

    }

    public void addResources(int[] hexNumbers) {
        if (hexNumbers[0] == 20 || hexNumbers[1] == 21)
        {
            int resources = lumber + ore + wool + grain + brick;
            float y = resources / 2;
            Debug.Log("rolled a Seven");
            Debug.Log("Player has this many resources:" + resources);
            if (resources > 7)
            {
                rollSeven(resources);
            }

           
        }
        else
        {
            //check if player owns settlements adjacent to scoring tiles
            for (int i = 0; i < settlements.Count; i++)
            {
                for (int x = 0; x < hexNumbers.Length; x++)
                {

                    //give player resources if they own scoring settlements
                    if (settlements[i] == hexNumbers[x])
                    {
                        switch (hexNumbers[x])
                        {
                            case 1:
                            case 9:
                            case 11:
                            case 19:
                                lumber += 1;
                                break;
                            case 2:
                            case 7:
                            case 14:
                            case 15:
                                wool += 1;
                                break;
                            case 5:
                            case 16:
                            case 17:
                                ore += 1;
                                break;
                            case 4:
                            case 6:
                            case 13:
                                brick += 1;
                                break;
                            case 3:
                            case 10:
                            case 12:
                            case 18:
                                grain += 1;
                                break;
                        } // end switch
                    } // end if statement
                }//end nested loop

            }// end complete loop
        }
        //updating UI after giving player resources
        updateResources();

    }

    public void updateResources() {
        lumberText.text = "Lumber: " + lumber;
        woolText.text = "Wool: " + wool;
        oreText.text = "Ore: " + ore;
        grainText.text = "Grain: " + grain;
        brickText.text = "Brick: " + brick;
        vpText.text = "Victory Points: " + vp;
        rCardsText.text = "Resource Cards: " + rCards;
        
    }


    //COST IS COMMENTED OUT UNTIL FINAL TESTING TO EASE CURRENT TESTING
    public void SpendRoad() {
        if (buildRoad == false)
        {
            if (gameBoard.gameStart) {
                if (firstRoads < 2)
                {
                    buildRoad = true;
                    Debug.Log("Able to build Road");
                    firstRoads += 1;
                }
            }
            else
            {
                if (brick >= 1 && lumber >= 1)
                {
                    brick -= 1;
                    lumber -= 1;
                    updateResources();
                    buildRoad = true;
                    Debug.Log("Able to build Road");
                }
            }
        }
    }

    public void SpendSettlement() {
        if (buildSettlement == false)
        {
            if (gameBoard.gameStart)
            {
                if (firstSettlements < 2)
                {
                    buildSettlement = true;
                    Debug.Log("Able to build Settlement");
                    firstSettlements += 1;
                }
            }
            else
            {
                if (brick >= 1 && lumber >= 1 && wool >= 1 && grain >= 1)
                {
                    brick -= 1;
                    lumber -= 1;
                    grain -= 1;
                    wool -= 1;
                    updateResources();
                    buildSettlement = true;
                    Debug.Log("Able to build Settlement");
                }
            }
        }
    }
    public void SpendDevelopment()
    {
        //   if (buildDevelopment == false)
        //   {
        //   if (ore > 1 && wool > 1 && grain >1)
        //   {
        //     ore -= 1;
        //     wool -= 1;
        //     grain -= 1;
        //     rCards += 1;
        //  updateResources();
        buildDevelopment = true;
        // }
        //  }
    }

    public void startResources() {

        for (int i = 0; i < settlements.Count; i++) {
            switch (settlements[i])
            {
                case 1:
                case 9:
                case 11:
                case 19:
                    lumber += 1;
                    break;
                case 2:
                case 7:
                case 14:
                case 15:
                    wool += 1;
                    break;
                case 5:
                case 16:
                case 17:
                    ore += 1;
                    break;
                case 4:
                case 6:
                case 13:
                    brick += 1;
                    break;
                case 3:
                case 10:
                case 12:
                case 18:
                    grain += 1;
                    break;
            } // end switch
            Debug.Log("looping");
        }

    }

    public void doTrade(int who, int tradeFor, int trading)
    {


    }

    private void Update()
    {
        updateResources();
    }
    public void rollSeven(int resources) {
        Debug.Log("take resources called");
        Debug.Log("function resources:" + resources);
       
                Debug.Log("Taking away resources");
        while (resources > 7)
        {
            if (lumber >= 1)
            {
                lumber -= 1;
            }
            if (wool >= 1)
            {
                wool -= 1;
            }
            if (grain >= 1)
            {
                grain -= 1;
            }
            if (ore >= 1)
            {
                ore -= 1;
            }
            if (brick >= 1)
            {
                brick -= 1;
            }
            resources = lumber + wool + grain + ore + brick;
        }


        }
        


}

 