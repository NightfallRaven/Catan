﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Roll_Dice : MonoBehaviour {

    public Text Dice;
    int roll;
    public Player_Statistic p1;
    public Player_Statistic p2;
    public Player_Statistic p3;
    public Player_Statistic p4;
    private int[] rolledHexes = new int[2];

    public void RollDice() {

        //Simulates Dice Roll and displays result
        roll = Random.Range(1, 7);
        roll += Random.Range(1, 7);
        Dice.text = "Dice Roll: " + roll;

        //Converts Dice Roll into Hex Tile Numbers
        switch (roll) {
            case 2:
                rolledHexes[0] = 18;
                rolledHexes[1] = 100;
                break;
            case 3:
                rolledHexes[0] = 9;
                rolledHexes[1] = 16;
                break;
            case 4:
                rolledHexes[0] = 4;
                rolledHexes[1] = 11;
                break;
            case 5:
                rolledHexes[0] = 6;
                rolledHexes[1] = 17;
                break;
            case 6:
                rolledHexes[0] = 5;
                rolledHexes[1] = 19;
                break;
            case 7:
                rolledHexes[0] =20;
                rolledHexes[1] =21;
                break;
            case 8:
                rolledHexes[0] = 12;
                rolledHexes[1] = 13;
                break;
            case 9:
                rolledHexes[0] = 3;
                rolledHexes[1] = 15;
                break;
            case 10:
                rolledHexes[0] = 7;
                rolledHexes[1] = 14;
                break;
            case 11:
                rolledHexes[0] = 1;
                rolledHexes[1] = 10;
                break;
            case 12:
                rolledHexes[0] = 2;
                rolledHexes[1] = 100;
                break;
        }

        //send the hexes that get resources to players 
        p1.addResources(rolledHexes);
        p2.addResources(rolledHexes);
        p3.addResources(rolledHexes);
        p4.addResources(rolledHexes);

    }


	// Use this for initialization
	void Start () {
        RollDice();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
