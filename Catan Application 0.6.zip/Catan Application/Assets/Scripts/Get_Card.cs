﻿using UnityEngine;
using System.Collections;

public class Buy_Development_Card : MonoBehaviour
{

    int drawcard;
    drawcard = Random.Range(1, 4);
    
    switch (Buy_Development_Card.drawCard)
        {
        case 1:
        break;
        }
    }

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
