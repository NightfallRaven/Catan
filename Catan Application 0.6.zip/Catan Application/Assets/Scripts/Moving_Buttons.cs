﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Moving_Buttons : MonoBehaviour {

    public Moving_Buttons p1;
    public Moving_Buttons p2;
    public Moving_Buttons p3;
    public Moving_Buttons p4;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
