﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Game_Mechanics : MonoBehaviour {

    int turnNumber =1;
    public Text turnPlayer;
    public Text turnNumText; 
    public Material playerOneColor;
    public Material playerTwoColor;
    public Material playerThreeColor;
    public Material playerFourColor;


    public void changeTurn(int currentTurn) {
        turnNumber += 1;
        turnNumText.text ="Turn Number: " + turnNumber ;
        switch (currentTurn) {
            case 1:
                turnPlayer.text = "Two";
                break;
            case 2:
                turnPlayer.text = "Three";
                break;
            case 3:
                turnPlayer.text = "Four";
                break;
            case 4:
                turnPlayer.text = "One";
                break;
        }
    }

    public void placeSettlement(Renderer rend) {

        switch (turnPlayer.text) {
            case "One":
                rend.material = playerOneColor;        
                break;
            case "Two":
                rend.material = playerTwoColor;
                break;
            case "Three":
                rend.material = playerThreeColor;
                break;
            case "Four":
                rend.material = playerFourColor;
                break;
        }
    }
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
