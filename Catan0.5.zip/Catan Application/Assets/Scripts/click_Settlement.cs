﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class click_Settlement : MonoBehaviour {
    public Renderer rend;
    public Material playerOneColor;
    public Material playerTwoColor;
    public Material playerThreeColor;
    public Material playerFourColor;
    public Text turnPlayer;
    public int[] adjacentTiles = new int[3];
    public Player_Statistic p1;
    public Player_Statistic p2;
    public Player_Statistic p3;
    public Player_Statistic p4;



    public void OnMouseDown()
    {
        
        switch (turnPlayer.text)
        {
            case "One":
                if (p1.buildSettlement)
                {
                    rend.material = playerOneColor;
                    p1.addTiles(adjacentTiles);
                    p1.vp += 1;
                    p1.updateResources();
                    Debug.Log("Player One Placed a Settlement");
                    p1.buildSettlement = false;
                }
                break;
            case "Two":
                if (p2.buildSettlement)
                {
                    rend.material = playerTwoColor;
                    p2.addTiles(adjacentTiles);
                    p2.vp += 1;
                    Debug.Log("Player 2 Placed a Settlement");
                    p2.updateResources();
                    p2.buildSettlement = false;
                }
                break;
            case "Three":
                if (p3.buildSettlement)
                {
                    rend.material = playerThreeColor;
                    p3.addTiles(adjacentTiles);
                    p3.vp += 1;
                    p3.updateResources();
                    Debug.Log("Player 3 Placed a Settlement");
                    p3.buildSettlement = false;
                }
                break;
            case "Four":
                if (p4.buildSettlement)
                {
                    rend.material = playerFourColor;
                    p4.addTiles(adjacentTiles);
                    p4.vp += 1;
                    p4.updateResources();
                    Debug.Log("Player 4 Placed a Settlement");
                    p4.buildSettlement = false;
                }
                break;
        }

    }


	// Update is called once per frame
	void Update () {
		
	}
}
