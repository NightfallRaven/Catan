﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_Statistic : MonoBehaviour {
    //Player Resource Values
    int lumber;
    int ore;
    int wool;
    int grain;
    int brick;
    public int vp;
    int rCards;
    public Text lumberText;
    public Text oreText;
    public Text woolText;
    public Text brickText;
    public Text grainText;
    public Text vpText;
    public Text rCardsText;
    public bool buildSettlement = false;
    public bool buildRoad = false;
    //List element for storing which settlements the player owns
    public List<int> settlements = new List<int>();

    //adds tiles adjacent to the placed settlements to the players list for receiving resources
    public void addTiles (int[] hexes) {
        
        for (int i = 0; i < hexes.Length; i++)
        {
            settlements.Add(hexes[i]);          
        }

        Debug.Log("Settlements added to player");

    }

    public void addResources(int[] hexNumbers) {
        //check if player owns settlements adjacent to scoring tiles
        for (int i = 0; i < settlements.Count; i++)
        {
            for (int x = 0; x < hexNumbers.Length; x++)
            {

                //give player resources if they own scoring settlements
                if (settlements[i] == hexNumbers[x]) {
                    switch (hexNumbers[x])
                    {
                        case 1:
                        case 9:
                        case 11:
                        case 19:
                            lumber += 1;
                            break;
                        case 2:
                        case 7:
                        case 14:
                        case 15:
                            wool += 1;
                            break;
                        case 5:
                        case 16:
                        case 17:
                            ore += 1;
                            break;
                        case 4:
                        case 6:
                        case 13:
                            brick += 1;
                            break;
                        case 3:
                        case 10:
                        case 12:
                        case 18:
                            grain += 1;
                            break;
                    } // end switch
                } // end if statement
            }//end nested loop

        }// end complete loop

        //updating UI after giving player resources
        updateResources();

    }

    public void updateResources() {
        lumberText.text = "Lumber: " + lumber;
        woolText.text = "Wool: " + wool;
        oreText.text = "Ore: " + ore;
        grainText.text = "Grain: " + grain;
        brickText.text = "Brick: " + brick;
        vpText.text = "Victory Points: " + vp;
        //rCardsText.text = "Resource Cards: " + rCards;
        
    }


    //COST IS COMMENTED OUT UNTIL FINAL TESTING TO EASE CURRENT TESTING
    public void SpendRoad() {
     //   if (buildRoad == false)
     //   {
         //   if (brick > 1 && lumber > 1)
         //   {
           //     brick -= 1;
           //     lumber -= 1;
           //  updateResources();
                buildRoad = true;
           // }
      //  }
    }

    public void SpendSettlement() {
     //   if (buildSettlement == false)
     //   {
       //     if (brick > 1 && lumber > 1 && wool > 1 && grain > 1)
       //     {
       //         brick -= 1;
       //         lumber -= 1;
        //        grain -= 1;
        //        wool -= 1;
        //   updateResources();
                buildSettlement = true;
        //    }
     //   }
   }
}
