﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Game_Mechanics : MonoBehaviour
{

    public int turnNumber = 1;
    public Text turnPlayer;
    public Text turnNumText;
    public Material playerOneColor;
    public Material playerTwoColor;
    public Material playerThreeColor;
    public Material playerFourColor;
    public Game_Mechanics gameBoard;
    public bool gameStart;
    public Player_Statistic p1;
    public Player_Statistic p2;
    public Player_Statistic p3;
    public Player_Statistic p4;
    public GameObject mainbuttons1;
    public GameObject mainbuttons2;
    public GameObject mainbuttons3;
    public GameObject mainbuttons4;
    public GameObject tradebuttons1;
    public GameObject tradebuttons2;
    public GameObject tradebuttons3;
    public GameObject tradebuttons4;
    public GameObject tradingFor1;
    public GameObject tradingFor2;
    public GameObject tradingFor3;
    public GameObject tradingFor4;
    public GameObject trading1;
    public GameObject trading2;
    public GameObject trading3;
    public GameObject trading4;
    public int TempTradePerson;
    public int TempTradeResource;
    public int TempTradeValue;
    Player_Statistic temp;
    Player_Statistic temp2;
    public bool tradeSystem = false;
    public Text rules;


    public void changeTurn(int currentTurn)
    {
        turnNumber += 1;
        cancelTrade();
        turnNumText.text = "Turn Number: " + turnNumber;
        if (turnNumber == 9)
        {
            p1.startResources();
            p2.startResources();
            p3.startResources();
            p4.startResources();
            p1.updateResources();
            p2.updateResources();
            p3.updateResources();
            p4.updateResources();
        }
        switch (currentTurn)
        {
            case 1:
                turnPlayer.text = "Two";
                mainbuttons1.SetActive(false);
                mainbuttons2.SetActive(true);
                break;
            case 2:
                turnPlayer.text = "Three";
                mainbuttons2.SetActive(false);
                mainbuttons3.SetActive(true);
                break;
            case 3:
                turnPlayer.text = "Four";
                mainbuttons3.SetActive(false);
                mainbuttons4.SetActive(true);
                break;
            case 4:
                turnPlayer.text = "One";
                mainbuttons4.SetActive(false);
                mainbuttons1.SetActive(true);
                break;
        }
    }

    public void placeSettlement(Renderer rend)
    {

        switch (turnPlayer.text)
        {
            case "One":
                rend.material = playerOneColor;
                break;
            case "Two":
                rend.material = playerTwoColor;
                break;
            case "Three":
                rend.material = playerThreeColor;
                break;
            case "Four":
                rend.material = playerFourColor;
                break;
        }
    }
    // Use this for initialization
    void Start()
    {
        gameStart = true;
        mainbuttons2.SetActive(false);
        mainbuttons3.SetActive(false);
        mainbuttons4.SetActive(false);
        tradebuttons1.SetActive(false);
        tradebuttons2.SetActive(false);
        tradebuttons3.SetActive(false);
        tradebuttons4.SetActive(false);
        tradingFor1.SetActive(false);
        trading1.SetActive(false);
        tradingFor2.SetActive(false);
        trading2.SetActive(false);
        tradingFor3.SetActive(false);
        trading3.SetActive(false);
        tradingFor4.SetActive(false);
        trading4.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {
        if (turnNumber == 9)
        {
            gameStart = false;
            rules.text = "";
        }
        if (p1.vp >= 10)
        {
            SceneManager.LoadScene("Player One Wins");
        }
        if (p2.vp >= 10)
        {
            SceneManager.LoadScene("Player Two Wins");
        }
        if (p3.vp >= 10)
        {
            SceneManager.LoadScene("Player Three Wins");
        }
        if (p4.vp >= 10)
        {
            SceneManager.LoadScene("Player Four Wins");
        }
        switch (turnNumber) {
            case 2:
                rules.text = "Player Two: place one settlement and one road then end turn";
                break;
            case 3:
                rules.text = "Player Three: place one settlement and one road then end turn";
                break;
            case 4:
                rules.text = "Player Four: place one settlement and one road then end turn";
                break;
            case 5:
                rules.text = "Player One: place one settlement and one road then end turn";
                break;
            case 6:
                rules.text = "Player Two: place one settlement and one road then end turn";
                break;
            case 7:
                rules.text = "Player Three: place one settlement and one road then end turn";
                break;
            case 8:
                rules.text = "Player Four: place one settlement and one road then end turn";
                break;

        }
    }

    //Bad Code For Trading with Players
    public void startTrade(Player_Statistic trader)
    {
        
        switch (turnPlayer.text) {
            case "One":
                tradebuttons1.SetActive(true);
                break;
            case "Two":
                tradebuttons2.SetActive(true);
                break;
            case "Three":
                tradebuttons3.SetActive(true);
                break;
            case "Four":
                tradebuttons4.SetActive(true);
                break;

        }

        temp2 = trader ;
    }
    public void selectTrader(int whosTrading)
    {

        switch (turnPlayer.text)
        {
            case "One":
                tradebuttons1.SetActive(false);
                tradingFor1.SetActive(true);
                break;
            case "Two":
                tradebuttons2.SetActive(false);
                tradingFor2.SetActive(true);
                break;
            case "Three":
                tradebuttons3.SetActive(false);
                tradingFor3.SetActive(true);
                break;
            case "Four":
                tradebuttons4.SetActive(false);
                tradingFor4.SetActive(true);
                break;

        }
                switch (whosTrading)
                {
                    case 1:
                        temp = p1;
                        break;
                    case 2:
                        temp = p2;
                        break;
                    case 3:
                        temp = p3;
                        break;
                    case 4:
                        temp = p4;
                        break;
                    case 5:
                        tradeSystem = true;
                        break;
                }
        
    }
    public void selectMaterial(int whatItem)
    {
        switch (turnPlayer.text)
        {
            case "One":
                tradingFor1.SetActive(false);
                trading1.SetActive(true);
                break;
            case "Two":
                tradingFor2.SetActive(false);
                trading2.SetActive(true);
                break;
            case "Three":
                tradingFor3.SetActive(false);
                trading3.SetActive(true);
                break;
            case "Four":
                tradingFor4.SetActive(false);
                trading4.SetActive(true);
                break;
        }


        switch (whatItem) {
            case 1:
                if (tradeSystem)
                {
                    temp2.lumber += 1;
                }
                else
                {
                    temp.lumber -= 1;
                    temp2.lumber += 1;
                }
                break;
            case 2:
                if (tradeSystem)
                {
                    temp2.ore += 1;
                }
                else {
                    temp.ore -= 1;
                    temp2.ore += 1;
                }
                break;
            case 3:
                if (tradeSystem)
                {
                    temp2.brick += 1;
                }
                else
                {
                    temp.brick -= 1;
                    temp2.brick += 1;
                }
                break;
            case 4:
                if (tradeSystem)
                {
                    temp2.wool += 1;
                }
                else
                {
                    temp.wool -= 1;
                    temp2.wool += 1;
                }
                break;
            case 5:
                if (tradeSystem)
                {
                    temp2.grain += 1;
                }
                else
                {
                    temp.grain -= 1;
                    temp2.grain += 1;
                }
                break;

        }
    }
    public void tradeResource(int whatTrading)
    {

        switch (turnPlayer.text)
        {
            case "One":
                tradebuttons1.SetActive(true);
                break;
            case "Two":
                tradebuttons2.SetActive(true);
                break;
            case "Three":
                tradebuttons3.SetActive(true);
                break;
            case "Four":
                tradebuttons4.SetActive(true);
                break;
        }
 

        switch (whatTrading) {
            case 1:
                if (tradeSystem)
                {
                    temp2.lumber -= 4;
                }
                else { 
                temp2.lumber -= 1;
                temp.lumber += 1; }
                break;
            case 2:
                if (tradeSystem)
                {
                    temp2.ore -= 4;
                }
                else
                {
                    temp2.ore -= 1;
                    temp.ore += 1;
                }
                break;
            case 3:
                if (tradeSystem)
                {
                    temp2.brick -= 4;
                }
                else
                {
                    temp2.brick -= 1;
                    temp.brick += 1;
                }
                break;
            case 4:
                if (tradeSystem)
                {
                    temp2.wool -= 4;
                }
                else
                {
                    temp2.wool -= 1;
                    temp.wool += 1;
                }
                break;
            case 5:
                if (tradeSystem)
                {
                    temp2.grain -= 4;
                }
                else
                {
                    temp2.grain -= 1;
                    temp.grain += 1;
                }
                break;

        }
        //completeTrade(TempTradePerson, TempTradeResource, TempTradeValue);
    }
    public void cancelTrade()
    {

        tradebuttons1.SetActive(false);
        tradebuttons2.SetActive(false);
        tradebuttons3.SetActive(false);
        tradebuttons4.SetActive(false);
        tradingFor1.SetActive(false);
        trading1.SetActive(false);
        tradingFor2.SetActive(false);
        trading2.SetActive(false);
        tradingFor3.SetActive(false);
        trading3.SetActive(false);
        tradingFor4.SetActive(false);
        trading4.SetActive(false);

    }
    //public void completeTrade(int who, int tradeFor, int trading)
    //{
    //    if (who == 1) {
    //        switch (trading) {
    //            case 1:
    //                if (p1.lumber > 3) {

    //                }
    //        }

    //    }
    //}

}