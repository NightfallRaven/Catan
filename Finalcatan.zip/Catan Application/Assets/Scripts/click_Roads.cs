﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class click_Roads : MonoBehaviour {


    public Renderer rend;
    public Renderer adjacent1;
    public Renderer adjacent2;
    public Renderer adjacentRoad1;
    public Renderer adjacentRoad2;
    public Renderer adjacentRoad3;
    public Renderer adjacentRoad4;
    public Material playerOneColor;
    public Material playerTwoColor;
    public Material playerThreeColor;
    public Material playerFourColor;
    public Material BlockBuild;
    public Material FreeBuild;
    public Text turnPlayer;
    public int[] adjacentTiles = new int[3];
    public Player_Statistic p1;
    public Player_Statistic p2;
    public Player_Statistic p3;
    public Player_Statistic p4;
    public Game_Mechanics gameBoard;
    


    public void OnMouseDown()
    {
        
            switch (turnPlayer.text)
            {
                case "One":


                    if (p1.buildRoad && rend.material.color == Color.white)
                    {

                        rend.material = playerOneColor;

                        if (adjacentRoad1.material.color == Color.black)
                    {
                        adjacentRoad1.material.color = Color.white;
                    }
                        if (adjacentRoad2.material.color == Color.black)
                    {
                        adjacentRoad2.material.color = Color.white;
                    }
                        if (adjacentRoad3.material.color == Color.black)
                    {
                        adjacentRoad3.material.color = Color.white;
                    }
                        if (adjacentRoad4.material.color == Color.black)
                    {
                        adjacentRoad4.material.color = Color.white;
                    }

                    if (adjacent1.material.color == Color.grey)
                    {
                        adjacent1.material.color = Color.white;
                    }
                    if (adjacent2.material.color == Color.grey)
                    {
                        adjacent2.material.color = Color.white;
                    }

                    p1.updateResources();
                        Debug.Log("Player One Placed a Road");
                        p1.buildRoad = false;

                    }

                    break;
                case "Two":
                    if (p2.buildRoad && rend.material.color == Color.white)
                    {

                        rend.material = playerTwoColor;

                         if (adjacentRoad1.material.color == Color.black)
                    {
                        adjacentRoad1.material.color = Color.white;
                    }
                         if (adjacentRoad2.material.color == Color.black)
                    {
                        adjacentRoad2.material.color = Color.white;
                    }
                         if (adjacentRoad3.material.color == Color.black)
                    {
                        adjacentRoad3.material.color = Color.white;
                    }
                         if (adjacentRoad4.material.color == Color.black)
                    {
                        adjacentRoad4.material.color = Color.white;
                    }

                    if (adjacent1.material.color == Color.grey) {
                        adjacent1.material.color = Color.white;
                    }
                    if (adjacent2.material.color == Color.grey)
                    {
                        adjacent2.material.color = Color.white;
                    }
                    Debug.Log("Player 2 Placed a Road");
                        p2.updateResources();
                        p2.buildRoad = false;


                    }

                    break;
                case "Three":
                    if (p3.buildRoad && rend.material.color == Color.white)
                    {


                        rend.material = playerThreeColor;

                    if (adjacentRoad1.material.color == Color.black)
                    {
                        adjacentRoad1.material.color = Color.white;
                    }
                    if (adjacentRoad2.material.color == Color.black)
                    {
                        adjacentRoad2.material.color = Color.white;
                    }
                    if (adjacentRoad3.material.color == Color.black)
                    {
                        adjacentRoad3.material.color = Color.white;
                    }
                    if (adjacentRoad4.material.color == Color.black)
                    {
                        adjacentRoad4.material.color = Color.white;
                    }


                    if (adjacent1.material.color == Color.grey)
                    {
                        adjacent1.material.color = Color.white;
                    }
                    if (adjacent2.material.color == Color.grey)
                    {
                        adjacent2.material.color = Color.white;
                    }
                    p3.updateResources();
                        Debug.Log("Player 3 Placed a Road");
                        p3.buildRoad = false;



                    }


                    break;
                case "Four":
                    if (p4.buildRoad && rend.material.color == Color.white)
                    {


                        rend.material = playerFourColor;

                       if (adjacentRoad1.material.color == Color.black)
                    {
                        adjacentRoad1.material.color = Color.white;
                    }
                       if (adjacentRoad2.material.color == Color.black)
                    {
                        adjacentRoad2.material.color = Color.white;
                    }
                       if (adjacentRoad3.material.color == Color.black)
                    {
                        adjacentRoad3.material.color = Color.white;
                    }
                       if (adjacentRoad4.material.color == Color.black)
                    {
                        adjacentRoad4.material.color = Color.white;
                    }


                    if (adjacent1.material.color == Color.grey)
                    {
                        adjacent1.material.color = Color.white;
                    }
                    if (adjacent2.material.color == Color.grey)
                    {
                        adjacent2.material.color = Color.white;
                    }
                    p4.updateResources();
                        Debug.Log("Player 4 Placed a Road");
                        p4.buildRoad = false;


                    }           
                    break;

            

        }
    }
    // Use this for initialization
    void Start () {

        rend.material.color = Color.black;

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
